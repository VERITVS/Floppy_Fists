# Floppy_Fists

## Installation
If there is a node_modules folder on install, delete it. Then run the commands:
```
npm install --save three
npm install --save-dev vite
```

## Running
```
npx vite
```
Then open in your local browser at localhost with the port given by vite.
